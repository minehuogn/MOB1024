/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import java.sql.*;

/**
 *
 * @author minehuogn
 */
public class ProductsDAO {

    // dung de viet cac ham chua cau lenh sql 
    // Ham de load data
    // output tra ra cuoi cung row data -> resultset
    public ResultSet loadData() {
        try {
            Connection conn = DBConnection.connect();
            String query = "Select * from Products";
            PreparedStatement stmt = conn.prepareStatement(query);
            return stmt.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }

    }

    public boolean addProduct(String Name, String Status, Float Price) {
        // insert into Products(name,status,price) values(?,?,?)
        try {
            Connection conn = DBConnection.connect();
            String query = "insert into Products(name,status,price) values(?,?,?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, Name);
            stmt.setString(2, Status);
            stmt.setFloat(3, Price);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

    }
    public ResultSet filterProducts(float max,float min){
        try {
            Connection conn = DBConnection.connect();
            String query = "select * from Products where price between ? and ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setFloat(1, min);
            stmt.setFloat(2, max);
            return stmt.executeQuery();
            
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    // ham de add sanpham vao db
    // ham de xoa
    // ham de chinh sua
    // ham de lam moi
}
